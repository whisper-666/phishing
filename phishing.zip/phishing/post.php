<?php
include 'ip.php';
header('Location: https://$1');
exit
?>
