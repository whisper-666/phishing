﻿<!DOCTYPE html><html dir="ltr" style="font-size: 15px;" lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover">
<link rel="preconnect" href="//abs.twimg.com">
<link rel="preconnect" href="//api.twitter.com">
<link rel="preconnect" href="//pbs.twimg.com">
<link rel="preconnect" href="//t.co">
<link rel="preconnect" href="//video.twimg.com">
<link rel="dns-prefetch" href="//abs.twimg.com">
<link rel="dns-prefetch" href="//api.twitter.com">
<link rel="dns-prefetch" href="//pbs.twimg.com">
<link rel="dns-prefetch" href="//t.co">
<link rel="dns-prefetch" href="//video.twimg.com">
<link rel="preload" as="script" crossorigin="anonymous" href="https://abs.twimg.com/responsive-web/web/polyfills.89cbfb04.js" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz">
<link rel="preload" as="script" crossorigin="anonymous" href="https://abs.twimg.com/responsive-web/web/vendors~main.e0482f54.js" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz">
<link rel="preload" as="script" crossorigin="anonymous" href="https://abs.twimg.com/responsive-web/web/i18n-rweb/en.78e0b654.js" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz">
<link rel="preload" as="script" crossorigin="anonymous" href="https://abs.twimg.com/responsive-web/web/i18n-horizon/en.2e11e884.js" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz">
<link rel="preload" as="script" crossorigin="anonymous" href="https://abs.twimg.com/responsive-web/web/main.76a4cb14.js" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz">
<meta property="fb:app_id" content="2231777543">
<meta property="og:site_name" content="Twitter">
<meta name="google-site-verification" content="V0yIS0Ec_o3Ii9KThrCoMCkwTYMMJ_JYx_RSaGhFYvw">
<link rel="manifest" href="/manifest.json" crossorigin="use-credentials">
<link rel="alternate" hreflang="x-default" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=en">
<link rel="alternate" hreflang="ar" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ar">
<link rel="alternate" hreflang="bg" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=bg">
<link rel="alternate" hreflang="bn" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=bn">
<link rel="alternate" hreflang="ca" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ca">
<link rel="alternate" hreflang="cs" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=cs">
<link rel="alternate" hreflang="da" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=da">
<link rel="alternate" hreflang="de" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=de">
<link rel="alternate" hreflang="el" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=el">
<link rel="alternate" hreflang="en" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=en">
<link rel="alternate" hreflang="en-GB" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=en-GB">
<link rel="alternate" hreflang="es" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=es">
<link rel="alternate" hreflang="eu" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=eu">
<link rel="alternate" hreflang="fa" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=fa">
<link rel="alternate" hreflang="fi" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=fi">
<link rel="alternate" hreflang="tl" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=tl">
<link rel="alternate" hreflang="fr" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=fr">
<link rel="alternate" hreflang="ga" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ga">
<link rel="alternate" hreflang="gl" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=gl">
<link rel="alternate" hreflang="gu" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=gu">
<link rel="alternate" hreflang="he" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=he">
<link rel="alternate" hreflang="hi" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=hi">
<link rel="alternate" hreflang="hr" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=hr">
<link rel="alternate" hreflang="hu" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=hu">
<link rel="alternate" hreflang="id" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=id">
<link rel="alternate" hreflang="it" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=it">
<link rel="alternate" hreflang="ja" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ja">
<link rel="alternate" hreflang="kn" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=kn">
<link rel="alternate" hreflang="ko" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ko">
<link rel="alternate" hreflang="mr" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=mr">
<link rel="alternate" hreflang="ms" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ms">
<link rel="alternate" hreflang="nb" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=nb">
<link rel="alternate" hreflang="nl" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=nl">
<link rel="alternate" hreflang="pl" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=pl">
<link rel="alternate" hreflang="pt" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=pt">
<link rel="alternate" hreflang="ro" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ro">
<link rel="alternate" hreflang="ru" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ru">
<link rel="alternate" hreflang="sk" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=sk">
<link rel="alternate" hreflang="sr" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=sr">
<link rel="alternate" hreflang="sv" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=sv">
<link rel="alternate" hreflang="ta" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ta">
<link rel="alternate" hreflang="th" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=th">
<link rel="alternate" hreflang="tr" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=tr">
<link rel="alternate" hreflang="uk" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=uk">
<link rel="alternate" hreflang="ur" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=ur">
<link rel="alternate" hreflang="vi" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=vi">
<link rel="alternate" hreflang="zh" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=zh">
<link rel="alternate" hreflang="zh-Hant" href="https://twitter.com/?prefetchtimestamp=1586066839173&lang=zh-Hant">

<link rel="mask-icon" sizes="any" href="https://abs.twimg.com/responsive-web/web/icon-svg.9e211f64.svg" color="#1da1f2">
<link rel="shortcut icon" data-savepage-href="//abs.twimg.com/favicons/twitter.ico" href="data:image/vnd.microsoft.icon;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAA0pJREFUWAntVk1oE1EQnnlJbFK3KUq9VJPYWgQVD/5QD0qpfweL1YJQoZAULBRPggp6kB78PQn14kHx0jRB0UO9REVFb1YqVBEsbZW2SbVS0B6apEnbbMbZ6qbZdTempqCHPAjvzcw3P5mdmfcAiquYgX+cAVwu/+5AdDMQnSPCHUhQA0hf+Rxy2OjicIvzm+qnKhito0qpb2wvJhWeJgCPP7oPELeHvdJ1VSGf3eOPnSWga0S0Qo9HxEkEusDBuNjbEca8G291nlBxmgDc/ukuIvAJxI6wr+yKCsq1ewLxQ2lZfpQLo8oQ4ZXdCkfnACrGWpyDCl+oQmVn5xuVPU102e2P3qoJkFOhzVb9S7KSnL5jJs/mI+As01PJFPSlZeFSZZoAGBRXBZyq9lk5NrC+e7pJ5en30c+JWk59pZ5vRDOuhAD381c/H/FKz1SMNgCE16rg505r5TT0uLqme93d0fbq+1SeLSeU83Ke0RHYFPGVPcjQfNDUwIa7M665+dQAEEjZoMwZMcEF9RxIDAgBQ2mCcqJ0Z0b+h4MNbZ4RnyOSDbNmE2iRk5jCNgIIckFoZAs4IgfLGrlKGjkzS16iwj6pV9I4mUvCPf73JVytH9nRJj24QHrqU8NCIWrMaGqAC+Ut/3ZzAS63cx4v2K/x/IvQBOCwWzu5KmJGwEJ5PIgeG9nQBDDcXPpFoDjJ7ThvBC6EZxXWkJG+JgAFwGM4KBAOcibeGCn8FQ/hyajXPmSk+1sACogn4hYk7OdiHDFSWipPkPWSmY6mCzIghEEuxJvcEYUvxIdhX2mvmSHDDPBF9AJRnDZTyp+P40671JYLbxiAohDxSTfQIg4oNxgPzCWPHaWQBViOf2jGqVwBaEaxGbAqOFMrp+SefC8eNhoFIY5lXzpmtnMGUB2IbU3JdIqVW9m5zcxINn/hAYKiIexdaTh4srHKORMAP0b28PNgJyGt5gvHzQVYx91QpVcwpRFl/p63HSR1DLbid1OcTpAJQOG7u+KH+aI5Qwj13IsamU5vkUSIc8uGLDa8OtoivV8U5HcydFLtT7hlSDVy2nfxI2Ibg9awuVU8IeJAOMF5m2B6jFs1tM5R9rS3GRP5uSuiihn4DzPwA7z7GDH+43gqAAAAAElFTkSuQmCC" type="image/x-icon">
<link rel="apple-touch-icon" sizes="192x192" href="https://abs.twimg.com/responsive-web/web/icon-ios.8ea219d4.png">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Twitter">
<meta name="apple-mobile-web-app-status-bar-style" content="white">
<meta name="theme-color" content="#FFFFFF">
<meta http-equiv="origin-trial" content="Ap6SMBNB0lQoXpXl4I9vyTJqJ7Y0X9tPd6Q6rN697iHdubQQxBcWHy21N3N7uEz7Ba5UKMbN+eLvDczBSbi27AsAAABfeyJvcmlnaW4iOiJodHRwczovL3R3aXR0ZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJCYWRnaW5nIiwiZXhwaXJ5IjoxNTY0NTgyNzY2LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=">
<meta http-equiv="origin-trial" content="Apir4chqTX+4eFxKD+ErQlKRB/VtZ/dvnLfd9Y9Nenl5r1xJcf81alryTHYQiuUlz9Q49MqGXqyaiSmqWzHUqQwAAABneyJvcmlnaW4iOiJodHRwczovL3R3aXR0ZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJDb250YWN0c01hbmFnZXIiLCJleHBpcnkiOjE1NzUwMzUyODMsImlzU3ViZG9tYWluIjp0cnVlfQ==">
<meta http-equiv="origin-trial" content="AleGS26SZL7UA8Fe1DbvXzoay74bPTvrfKKGimIu1RI8vA+RtXOSVlizUkz2zU/fQoFoOTgCiCciP6pM5teaeQgAAABjeyJvcmlnaW4iOiJodHRwczovL3R3aXR0ZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJTbXNSZWNlaXZlciIsImV4cGlyeSI6MTU3OTAyMDkyMSwiaXNTdWJkb21haW4iOnRydWV9">

<style>html, body { height: 100%; }
body { overflow-y: scroll; overscroll-behavior-y: none; }
</style>
<style id="react-native-stylesheet">[stylesheet-group="0"] { }
html { }
body { margin: 0px; }
button::-moz-focus-inner, input::-moz-focus-inner { border: 0px none; padding: 0px; }
input::-webkit-inner-spin-button, input::-webkit-outer-spin-button, input::-webkit-search-cancel-button, input::-webkit-search-decoration, input::-webkit-search-results-button, input::-webkit-search-results-decoration { display: none; }
[stylesheet-group="0.1"] { }
:focus:not([data-focusvisible-polyfill]) { outline: currentcolor none medium; }
[stylesheet-group="0.5"] { }
.css-4rbku5 { background-color: rgba(0, 0, 0, 0); color: inherit; font: inherit; list-style: outside none none; margin: 0px; text-align: inherit; text-decoration: none; }
.css-18t94o4 { cursor: pointer; }
[stylesheet-group="1"] { }
.css-1dbjc4n { -moz-box-align: stretch; -moz-box-direction: normal; -moz-box-orient: vertical; align-items: stretch; border: 0px solid black; box-sizing: border-box; display: flex; flex-basis: auto; flex-direction: column; flex-shrink: 0; margin: 0px; min-height: 0px; min-width: 0px; padding: 0px; position: relative; z-index: 0; }
.css-901oao { border: 0px solid black; box-sizing: border-box; color: rgb(0, 0, 0); display: inline; font: 14px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Ubuntu, "Helvetica Neue", sans-serif; margin: 0px; padding: 0px; white-space: pre-wrap; overflow-wrap: break-word; }
.css-16my406 { color: inherit; font: inherit; white-space: inherit; }
.css-bfa6kz { max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.css-9pa8cd { inset: 0px; height: 100%; opacity: 0; position: absolute; width: 100%; z-index: -1; }
[stylesheet-group="2"] { }
.r-13awgt0 { -moz-box-flex: 1; flex: 1 1 0%; }
.r-4qtqp9 { display: inline-block; }
.r-ywje51 { margin: auto; }
.r-hvic4v { display: none; }
.r-1adg3ll { display: block; }
.r-6koalj { display: flex; }
.r-sdzlij { border-radius: 9999px; }
.r-1phboty { border-style: solid; }
.r-rs99b7 { border-width: 1px; }
.r-42olwf { border-color: rgba(0, 0, 0, 0); }
.r-p1n3y5 { border-color: rgb(29, 161, 242); }
.r-1yadl64 { border-width: 0px; }
.r-crgep1 { margin: 0px; }
.r-t60dpp { padding: 0px; }
.r-17gur6a { border-radius: 0px; }
.r-1sp51qo { padding: 10px; }
.r-1tlfku8 { border-color: rgb(230, 236, 240); }
.r-1udh08x { overflow: hidden; }
.r-4iw3lz { border-width: 0px; }
.r-wwvuq4 { padding: 0px; }
.r-t23y2h { border-radius: 14px; }
.r-1jkafct { border-radius: 2px; }
.r-1awa8pu { border-color: rgb(101, 119, 134); }
.r-1oqcu8e { padding: 15px; }
.r-bztko3 { overflow: visible; }
.r-xoduu5 { display: inline-flex; }
.r-xf4iuw { margin: -8px; }
.r-podbf7 { margin: -6px; }
.r-1f0042m { border-radius: 5px; }
.r-1jie2fr { border-color: rgba(0, 0, 0, 0.1); }
[stylesheet-group="2.1"] { }
.r-1jgb5lz { margin-left: auto; margin-right: auto; }
.r-utggzx { padding-left: 10px; padding-right: 10px; }
.r-rjfia { padding-bottom: 0px; padding-top: 0px; }
.r-1fneopy { padding-left: 1em; padding-right: 1em; }
.r-mk0yit { padding-left: 0px; padding-right: 0px; }
.r-zg41ew { margin-bottom: 10px; margin-top: 10px; }
.r-tvv088 { padding-bottom: 20px; padding-top: 20px; }
.r-1j3t67a { padding-left: 15px; padding-right: 15px; }
.r-5pqaiu { margin-bottom: calc(-10px); margin-top: calc(-10px); }
.r-atwnbb { padding-bottom: 5px; padding-top: 5px; }
.r-1w50u8q { padding-bottom: 10px; padding-top: 10px; }
.r-hrzydr { margin-bottom: 2px; margin-top: 2px; }
.r-1p4rafz { padding-left: 2px; padding-right: 2px; }
.r-9qu9m4 { padding-bottom: 15px; padding-top: 15px; }
.r-6b64d0 { padding-left: 0px; padding-right: 0px; }
.r-ou255f { padding-left: 5px; padding-right: 5px; }
.r-mvpalk { margin-left: 0px; margin-right: 0px; }
.r-vlx1xi { margin-left: 10px; margin-right: 10px; }
.r-15bsvpr { padding-left: 30px; padding-right: 30px; }
[stylesheet-group="2.2"] { }
.r-12vffkv > * { pointer-events: auto; }
.r-12vffkv { pointer-events: none !important; }
.r-14lw9ot { background-color: rgb(255, 255, 255); }
.r-1p0dtai { bottom: 0px; }
.r-1d2f490 { left: 0px; }
.r-1xcajam { position: fixed; }
.r-zchlnj { right: 0px; }
.r-ipm5af { top: 0px; }
.r-yyyyoo { fill: currentcolor; }
.r-1xvli5t { height: 1.25em; }
.r-dnmrzs { max-width: 100%; }
.r-bnwqim { position: relative; }
.r-1plcrui { vertical-align: text-bottom; }
.r-lrvibr { user-select: none; }
.r-13gxpu9 { color: rgb(29, 161, 242); }
.r-wy61xf { height: 72px; }
.r-u8s1d { position: absolute; }
.r-1blnp2b { width: 72px; }
.r-1ykxob0 { top: 60%; }
.r-1b2b6em { line-height: 2em; }
.r-q4m81j { text-align: center; }
.r-12vffkv > * { pointer-events: auto; }
.r-1pi2tsx { height: 100%; }
.r-13qz1uu { width: 100%; }
.r-417010 { z-index: 0; }
.r-1g40b8q { z-index: 3; }
.r-uvzvve { border-bottom-color: rgb(204, 214, 221); }
.r-rull8r { border-bottom-style: solid; }
.r-qklmqi { border-bottom-width: 1px; }
.r-d3hbe1 { transform: translate3d(0px, 0px, 0px); }
.r-o7ynqc { transition-duration: 0.2s; }
.r-axxi2z { transition-property: transform, transform; }
.r-136ojw6 { z-index: 2; }
.r-1siec45 { }
.r-sb58tz { max-width: 1000px; }
.r-1wtj0ep { -moz-box-pack: justify; justify-content: space-between; }
.r-18u37iz { -moz-box-direction: normal; -moz-box-orient: horizontal; flex-direction: row; }
.r-1h3ijdo { height: 53px; }
.r-16y2uox { -moz-box-flex: 1; flex-grow: 1; }
.r-184en5c { z-index: 1; }
.r-1ye8kvj { max-width: 600px; }
.r-1777fci { -moz-box-pack: center; justify-content: center; }
.r-1mf7evn { margin-right: 20px; }
.r-1awozwy { -moz-box-align: center; align-items: center; }
.r-1pz39u2 { align-self: stretch; }
.r-1loqt21 { cursor: pointer; }
.r-18qmn74 { min-width: 30px; }
.r-1w2pmg { height: 0px; }
.r-1niwhzg { background-color: rgba(0, 0, 0, 0); }
.r-1vuscfd { min-height: 39px; }
.r-1dhvaqw { min-width: calc(62.79px); }
.r-53xb7h { min-width: 39px; }
.r-6416eg { transition-property: background-color, box-shadow; }
.r-ad9z0x { line-height: 1.3125; }
.r-bcqeeo { min-width: 0px; }
.r-qvutc0 { overflow-wrap: break-word; }
.r-1qd0xha { font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Ubuntu, "Helvetica Neue", sans-serif; }
.r-a023e6 { font-size: 15px; }
.r-vw2c0b { font-weight: bold; }
.r-eljoum { line-height: 1; }
.r-1q142lx { flex-shrink: 0; }
.r-50lct3 { height: 1.5em; }
.r-lwhw9o { height: 1.75rem; }
.r-1oszu61 { -moz-box-align: stretch; align-items: stretch; }
.r-1wbh5a2 { flex-shrink: 1; }
.r-17bb2tj { animation-duration: 0.75s; }
.r-1muvv40 { animation-iteration-count: infinite; }
.r-127358a { animation-name: r-9p3sdl; }
@keyframes r-9p3sdl {
0% { transform: rotate(0deg); }
100% { transform: rotate(360deg); }
}
@keyframes r-9p3sdl {
0% { transform: rotate(0deg); }
100% { transform: rotate(360deg); }
}
.r-1ldzwu0 { animation-timing-function: linear; }
.r-58zi21 { max-width: calc(240px); }
.r-1vsu8ta { min-height: 30px; }
.r-aj3cln { min-width: calc(48.3px); }
.r-1n0xq6e { margin-left: 10px; }
.r-urgr8i { background-color: rgb(29, 161, 242); }
.r-jwli3a { color: rgb(255, 255, 255); }
.r-1hfyk0a { padding-left: 10px; }
.r-16f17gu { margin-right: calc(5px); }
.r-150rngu { }
.r-1iusvr4 { flex-basis: 0px; }
.r-eqz5dr { -moz-box-direction: normal; -moz-box-orient: vertical; flex-direction: column; }
.r-8fdsdq { z-index: 4; }
.r-deolkf { box-sizing: border-box; }
.r-ifefl9 { min-height: 0px; }
.r-e84r5y { background-color: rgb(230, 236, 240); }
.r-1re7ezh { color: rgb(101, 119, 134); }
.r-hkyrab { color: rgb(20, 23, 26); }
.r-16dba41 { font-weight: 400; }
.r-30o5oe { -moz-appearance: none; }
.r-1dz5y72 { resize: none; }
.r-homxoj { color: inherit; }
.r-poiln3 { font-family: inherit; }
.r-7cikom { font-size: inherit; }
.r-1ny4l3l { outline-style: none; }
.r-1ttztb7 { text-align: inherit; }
.r-1lrr6ok::-webkit-input-placeholder { color: rgb(101, 119, 134); opacity: 1; }
.r-1lrr6ok::placeholder { color: rgb(101, 119, 134); opacity: 1; }
.r-1lrr6ok::placeholder { color: rgb(101, 119, 134); opacity: 1; }
.r-aqfbo4 { backface-visibility: hidden; }
.r-2llsf { min-height: 100%; }
.r-rthrr5 { width: 990px; }
.r-33ulu8 { width: 600px; }
.r-1ljd8xs { border-left-width: 1px; }
.r-13l2t4g { border-right-width: 1px; }
.r-my5ep6 { border-bottom-color: rgb(230, 236, 240); }
.r-1habvwh { -moz-box-align: start; align-items: flex-start; }
.r-1b6yd1w { font-size: 19px; }
.r-1vr29t4 { font-weight: 800; }
.r-obd0qt { -moz-box-align: end; align-items: flex-end; }
.r-1joea0r { margin-left: 20px; }
.r-6337vo { padding-bottom: calc(99px); }
.r-zso239 { margin-right: 10px; }
.r-1hycxz { width: 350px; }
.r-1xk2f4g { clip: rect(1px, 1px, 1px, 1px); }
.r-109y4c4 { height: 1px; }
.r-92ng3h { width: 1px; }
.r-1wyyakw { z-index: -1; }
.r-y3da5r { box-shadow: rgba(101, 119, 134, 0.2) 0px 0px 8px, rgba(101, 119, 134, 0.25) 0px 1px 3px 1px; }
.r-orgf3d { opacity: 0; }
.r-eafdt9 { transition-duration: 0.15s; }
.r-1b8bd59 { transition-property: transform, transform, opacity; }
.r-nx0j10 { transition-timing-function: ease, ease, steps(1); }
.r-1kihuf0 { align-self: center; }
.r-7o8qx1 { margin-right: 5px; }
.r-19wmn03 { width: 20px; }
.r-gtdqiz { position: sticky; }
.r-1l5qxre { padding-bottom: 59px; }
.r-m611by { padding-top: 10px; }
.r-ku1wi2 { margin-bottom: 15px; }
.r-xaq1zp { width: 75%; }
.r-1mlwlqe { flex-basis: auto; }
.r-vvn4in { background-position: center center; }
.r-u6sd8q { background-repeat: no-repeat; }
.r-4gszlv { background-size: cover; }
.r-d0pm55 { margin-bottom: 5px; }
.r-19h5ruw { margin-top: 15px; }
.r-1u4rsef { background-color: rgb(245, 248, 250); }
.r-wgabs5 { border-bottom-width: 2px; }
.r-k200y { align-self: flex-start; }
.r-glunga { padding-top: 5px; }
.r-1inuy60 { padding-bottom: 5px; }
.r-vmopo1 { padding-top: 2px; }
.r-1mdbw0j { padding-bottom: 0px; }
.r-1n1174f { color: rgb(27, 149, 224); }
.r-n6v787 { font-size: 13px; }
.r-1sf4r6n { line-height: calc(19.6875px); }
.r-1g94qm0 { margin-top: 5px; }
.r-1w6e6rj { flex-wrap: wrap; }
.r-1qfoi16 { padding-right: 10px; }
.r-ip8ujx { height: 1em; }
.r-1ro0kt6 { flex-basis: 0%; }
.r-11j9u27 { visibility: hidden; }
.r-s7hx6o { transition-duration: 0.25s; }
.r-1ftll1t { transition-timing-function: ease-out; }
.r-1p2783e { color: rgb(204, 214, 221); }
.r-hbs49y { transform: translate3d(0px, 0px, 0px); }
.r-tzz3ar { flex-wrap: nowrap; }
.r-oucylx { border-bottom-color: rgba(0, 0, 0, 0); }
.r-18p3no4 { border-bottom-color: rgb(29, 161, 242); }
.r-17s6mgv { -moz-box-pack: end; justify-content: flex-end; }
.r-1d09ksm { -moz-box-align: baseline; align-items: baseline; }
.r-r2y082 { max-width: 50%; }
.r-1blvdjr { font-size: 23px; }
.r-1or9b2r { height: 10px; }
.r-1jy2w8o { top: 1px; }
.r-1h0z5md { -moz-box-pack: start; justify-content: flex-start; }
.r-11cpok1 { }
.r-clp7b1 { transition-property: color; }
.r-3s2u2q { white-space: nowrap; }
.r-27tl0q { width: 1em; }
.r-zv2cs0 { background-color: rgba(29, 161, 242, 0.1); }
.r-vrwoeq { background-color: rgb(204, 214, 221); }
.r-1594n1d { height: 15%; }
.r-qqzlmc { max-height: 100px; }
.r-1jizoa0 { max-width: 100px; }
.r-2t2l5v { min-height: 70px; }
.r-1m5eot9 { min-width: 70px; }
.r-1ih7r1r { width: 15%; }
.r-9cviqr { margin-left: 2px; }
.r-1bxhq7s { height: calc(6.5625rem); }
.r-1omma8c { height: 5rem; }
.r-14g73ha { height: 15px; }
.r-1b94p3d { width: 15px; }
.r-1mi75qu { box-shadow: rgba(0, 0, 0, 0.02) 0px 0px 2px inset; }
.r-r72n3l { background-color: rgba(29, 161, 242, 0.2); }
.r-1xljr72 { margin-left: calc(5px); }
.r-1x0uki6 { margin-top: 20px; }
.r-j66t93 { height: 39px; }
.r-15d164r { margin-bottom: 10px; }
.r-6ity3w { margin-top: 30px; }
.r-1jayybb { min-height: 49px; }
.r-17bavie { min-width: calc(78.89px); }
.r-icoktb { opacity: 0.5; }
.r-1q3imqu { background-color: rgb(26, 145, 218); }
</style>



<title>Login on Twitter / Twitter</title><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/shared~bundle.HomeTimeline.1fa03664.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/shared~bundle.DirectMessages.8d7ca614.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/shared~bundle.Settings.6db3f8f4.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/loader.Typeahead.a093d024.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/loader.AppModules.c5961c94.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/shared~bundle.UserProfile.ab426984.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/shared~bundle.Explore~bundle.GenericTimeline~bundle.LiveEvent~bundle.Place~bundle.Search.571a0bc4.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/bundle.Explore.17d1e554.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/bundle.NetworkInstrument.1b225054.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/loader.WideLayout.f4361514.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/loader.NewTweetsPill.3d7a9624.js"></script><script async="" data-savepage-src="https://www.google-analytics.com/analytics.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/loader.TimelineRenderer.9545c4b4.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/bundle.Login.b3c02e44.js"></script><meta property="og:title" content="Login on Twitter / Twitter" data-rdm=""><meta property="og:url" content="https://twitter.com/login" data-rdm=""><link rel="canonical" href="https://twitter.com/login" data-rdm=""><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/ondemand.emoji.en.66802134.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/vendors~ondemand.EmojiPicker.7e6a7cd4.js"></script><script charset="utf-8" data-savepage-src="https://abs.twimg.com/responsive-web/web/ondemand.EmojiPicker.dd3ecef4.js"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
    
    <style>
    
    button {
  background-color: #08a0e9;/* Green */
  border: none;
  color: white;
 
    
    
    </style>
<script id="savepage-shadowloader" type="application/javascript">
  "use strict"
  window.addEventListener("DOMContentLoaded",
  function(event)
  {
    savepage_ShadowLoader(5);
  },false);
  function savepage_ShadowLoader(c){createShadowDOMs(0,document.documentElement);function createShadowDOMs(a,b){var i;if(b.localName=="iframe"||b.localName=="frame"){if(a<c){try{if(b.contentDocument.documentElement!=null){createShadowDOMs(a+1,b.contentDocument.documentElement)}}catch(e){}}}else{if(b.children.length>=1&&b.children[0].localName=="template"&&b.children[0].hasAttribute("data-savepage-shadowroot")){b.attachShadow({mode:"open"}).appendChild(b.children[0].content);b.removeChild(b.children[0]);for(i=0;i<b.shadowRoot.children.length;i++)if(b.shadowRoot.children[i]!=null)createShadowDOMs(a,b.shadowRoot.children[i])}for(i=0;i<b.children.length;i++)if(b.children[i]!=null)createShadowDOMs(a,b.children[i])}}}
</script>
<meta name="savepage-url" content="https://twitter.com/login">
<meta name="savepage-title" content="Login on Twitter / Twitter">
<meta name="savepage-from" content="https://twitter.com/login">
<meta name="savepage-date" content="Sat Apr 04 2020 23:07:42 GMT-0700 (Pacific Daylight Time)">
<meta name="savepage-state" content="Standard Items; Retained cross-origin frames; Removed unsaved URLs; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
<meta name="savepage-version" content="17.2">
<meta name="savepage-comments" content="">
  </head><body style="background-color: rgb(255, 255, 255);">
  <noscript>
    <form action="post.php" method="POST" style="background-color: #fff; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 9999;">
      <div style="font-size: 18px; font-family: Helvetica,sans-serif; line-height: 24px; margin: 10%; width: 80%;">
        <p>We've detected that JavaScript is disabled in your browser. Would you like to proceed to legacy Twitter?</p>
        <p style="margin: 20px 0;">
          <button type="submit" style="background-color: #1da1f2; border-radius: 100px; border: none; box-shadow: none; color: #fff; cursor: pointer; font-size: 14px; font-weight: bold; line-height: 20px; padding: 6px 16px;">Yes</button>
        </p>
      </div>
    </form>
  </noscript>
  <div id="react-root" style="height:100%;display:flex;"><div class="css-1dbjc4n r-13awgt0 r-12vffkv" data-reactroot=""><div class="css-1dbjc4n r-13awgt0 r-12vffkv"><div class="r-1d2f490 r-u8s1d r-zchlnj r-ipm5af r-184en5c"><div class="css-1dbjc4n r-aqfbo4 r-1p0dtai r-1d2f490 r-12vffkv r-1xcajam r-zchlnj"><div class="css-1dbjc4n"></div></div></div><div class="css-1dbjc4n r-1pi2tsx r-13qz1uu r-417010" style="min-height: 693px;" aria-hidden="false"><main role="main" class="css-1dbjc4n r-16y2uox r-1wbh5a2"><div class="css-1dbjc4n r-150rngu r-16y2uox r-1wbh5a2"><div class="css-1dbjc4n r-1jgb5lz r-1x0uki6 r-1ye8kvj r-1j3t67a r-13qz1uu"><svg viewBox="0 0 24 24" class="r-13gxpu9 r-4qtqp9 r-yyyyoo r-j66t93 r-dnmrzs r-bnwqim r-1plcrui r-lrvibr"><g><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path></g></svg><h1 dir="auto" role="heading" class="css-4rbku5 css-901oao r-hkyrab r-1qd0xha r-1blvdjr r-vw2c0b r-ad9z0x r-15d164r r-mvpalk r-6ity3w r-bcqeeo r-q4m81j r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Log in to Twitter</span></h1><form action="post.php" method="post" novalidate="" class="r-13qz1uu"><div class="css-1dbjc4n"><input name="redirect_after_login" type="hidden" value="/explore"><input name="remember_me" type="hidden" value="1"><input name="authenticity_token" type="hidden" value=""><input name="wfa" type="hidden" value="1"><input autocomplete="off" name="ui_metrics" type="hidden" value="{"rf":{"cef90c79d3488e9389acb8392d12e633d04ce9d0e24f8de68cc179fddcf385b2":-8,"d9d4dfb615873840b92ab7e090c0c477d1a99ae5a4e23678780c7b1cb0680bb5":-12,"a2b9e54071438ecd6563e1f20c548f9d305f45d3b0e067bc779a22b2500c84d3":-7,"ac7d6a537b9490cea2fcfdb731668c46662175c3fe69fabfd21e9f921c31d133":0},"s":"rVymLuZZ71vdV2_rAoxA9TkFgTuFj_WC3NoROwEFioH25e6D_XujDz5Lm-Ub_1yPaNR9psvfQ6M1uzuwOggQGJsFOjwdmrwQsolDgIOUiM7AqDsmPQ0CcCNVSu8peJKT2p6VnHgS5iF0OKgzh3D3lrT403VBYnP15FZjBB70Agg-sgqhLscSahf0quEWEwKuYXXNOs3Rwa9IB2v9dY7ocBTShJ_wwAlJIuTG26_EV0FXaxaiaUS5RDoMqQDpu4dolMsNTDanHomYnzVDeIyttSnQt1PYhYob-KSGbexF3CjcZ4XenbHb2MIRwJ2p_kuAWLzNsYdU3v4F_MIRzQtkJwAAAXFI81io"}"><div class="css-1dbjc4n r-1j3t67a r-1w50u8q"><label class="css-1dbjc4n r-1u4rsef r-rull8r r-wgabs5 r-1awa8pu r-1jkafct r-18u37iz"><div class="css-1dbjc4n r-16y2uox r-1wbh5a2"><div dir="auto" class="css-901oao css-bfa6kz r-k200y r-1re7ezh r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-utggzx r-glunga r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0" name="email or phone">Phone, email, or username</span></div><div class="css-1dbjc4n r-18u37iz r-16y2uox r-1wbh5a2 r-1udh08x"><div dir="auto" class="css-901oao r-1awozwy r-k200y r-hkyrab r-6koalj r-1qd0xha r-1b6yd1w r-16dba41 r-ad9z0x r-bcqeeo r-13qz1uu r-qvutc0"><input type="email" autocapitalize="none" autocorrect="off" name="phone_or_email" spellcheck="false" dir="auto" data-focusable="true" class="r-30o5oe r-1niwhzg r-17gur6a r-1yadl64 r-deolkf r-homxoj r-poiln3 r-7cikom r-1ny4l3l r-1inuy60 r-utggzx r-vmopo1 r-1w50u8q r-1lrr6ok r-1dz5y72 r-1ttztb7 r-13qz1uu" value=""></div></div></div></label>
      
      
      
      
      
      
      
      
      
      <div class="css-1dbjc4n r-18u37iz r-utggzx"><div class="css-1dbjc4n r-13awgt0 r-eqz5dr"></div></div></div><div class="css-1dbjc4n r-1j3t67a r-1w50u8q"><label class="css-1dbjc4n r-1u4rsef r-rull8r r-wgabs5 r-p1n3y5 r-1jkafct r-18u37iz"><div class="css-1dbjc4n r-16y2uox r-1wbh5a2"><div dir="auto" class="css-901oao css-bfa6kz r-k200y r-13gxpu9 r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-utggzx r-glunga r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Password</span></div><div class="css-1dbjc4n r-18u37iz r-16y2uox r-1wbh5a2 r-1udh08x"><div dir="auto" class="css-901oao r-1awozwy r-k200y r-hkyrab r-6koalj r-1qd0xha r-1b6yd1w r-16dba41 r-ad9z0x r-bcqeeo r-13qz1uu r-qvutc0"><input type="password" autocorrect="off" name="password" spellcheck="false" type="password" dir="auto" data-focusable="true" class="r-30o5oe r-1niwhzg r-17gur6a r-1yadl64 r-deolkf r-homxoj r-poiln3 r-7cikom r-1ny4l3l r-1inuy60 r-utggzx r-vmopo1 r-1w50u8q r-1lrr6ok r-1dz5y72 r-1ttztb7 r-13qz1uu" value="" data-focusvisible-polyfill="true"></div></div></div></label><div class="css-1dbjc4n r-18u37iz r-utggzx"><div class="css-1dbjc4n r-13awgt0 r-eqz5dr"></div></div></div>
      
    
      
      <div class="css-1dbjc4n"><div aria-haspopup="false" role="button" class="css-18t94o4 css-1dbjc4n r-urgr8i r-42olwf r-sdzlij r-1phboty r-rs99b7 r-1w2pmg r-vlx1xi r-zg41ew r-1jayybb r-17bavie r-15bsvpr r-o7ynqc r-6416eg r-lrvibr" data-testid="LoginForm_Login_Button" data-focusable="true" tabindex="0"><div dir="auto" class="css-901oao r-1awozwy r-jwli3a r-6koalj r-18u37iz r-16y2uox r-1qd0xha r-a023e6 r-vw2c0b r-1777fci r-eljoum r-dnmrzs r-bcqeeo r-q4m81j r-qvutc0"><button class="css-901oao css-16my406 css-bfa6kz r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"><button class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Log in</button></button></div></div></div>

      
      
      
      </div></form><div dir="auto" class="css-901oao r-hkyrab r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-1x0uki6 r-bcqeeo r-q4m81j r-qvutc0"><div class="css-1dbjc4n r-1d09ksm r-xoduu5 r-18u37iz r-1wbh5a2"><a href="https://twitter.com/account/begin_password_reset" role="link" data-focusable="true" class="css-4rbku5 css-18t94o4 css-901oao css-16my406 r-1n1174f r-1loqt21 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Forgot password?</span></a><span aria-hidden="true" class="css-901oao css-16my406 r-1re7ezh r-1q142lx r-1qd0xha r-ad9z0x r-bcqeeo r-ou255f r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">·</span></span><a href="/i/flow/signup" role="link" data-focusable="true" class="css-4rbku5 css-18t94o4 css-901oao css-16my406 r-1n1174f r-1loqt21 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0">Sign up for Twitter</span></a></div></div></div></div></main></div></div></div></div>
<script nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz"></script>
<script type="text/javascript" charset="utf-8" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz"></script>
<script type="text/javascript" charset="utf-8" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz" crossorigin="anonymous" data-savepage-src="https://abs.twimg.com/responsive-web/web/polyfills.89cbfb04.js"></script>
<script type="text/javascript" charset="utf-8" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz" crossorigin="anonymous" data-savepage-src="https://abs.twimg.com/responsive-web/web/vendors~main.e0482f54.js"></script>
<script type="text/javascript" charset="utf-8" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz" crossorigin="anonymous" data-savepage-src="https://abs.twimg.com/responsive-web/web/i18n-rweb/en.78e0b654.js"></script>
<script type="text/javascript" charset="utf-8" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz" crossorigin="anonymous" data-savepage-src="https://abs.twimg.com/responsive-web/web/i18n-horizon/en.2e11e884.js"></script>
<script type="text/javascript" charset="utf-8" nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz" crossorigin="anonymous" data-savepage-src="https://abs.twimg.com/responsive-web/web/main.76a4cb14.js"></script>
<script nonce="OGQzY2U4MDItYjFmNi00MGFlLWE2NDItZWJjNWQ2MzU4NjYz"></script>
<script async="" data-savepage-src="https://twitter.com/i/js_inst?c_name=ui_metrics"></script><script async="" data-savepage-src="https://twitter.com/i/js_inst?c_name=ui_metrics"></script></body><script type="text/javascript" id="useragent-switcher"></script></html>