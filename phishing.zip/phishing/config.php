<?php

$sender_name = 'name'; 
$sender_mail = 'emai';
$sender_pass = 'password';

$receiver_name = 'name';
$receiver_mail = 'emal';

?>
