![](https://img.shields.io/badge/lovehacker404-BlackMafia-orange?style=for-the-badge&logo=python.svg) 
<p align="center">
<img src="blackmafia31.jpg">
<a href="#"><img title="Made in Pakistan" src="https://img.shields.io/badge/MADE%20IN-Pakistan-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
  <img alt="lovehacker404' Github Stats" src="https://github-readme-stats.vercel.app/api?username=lovehacker404&show_icons=true&include_all_commits=true&hide_border=true" />
<!--  <img alt="profile pic" width="195px" src="https://avatars2.githubusercontent.com/u/26059688?s=460&u=d41b000a62eab50d000c3da604d151cec27bd850&v=4" />  -->
<!--  <img src="https://github-readme-stats.anuraghazra1.vercel.app/api/top-langs/?username=lovehacker404&hide=ruby,perl&hide_border=true" />  -->
</p>
<p align="center">
<a href="#"><img title="WhatsApp Num" src="https://img.shields.io/badge/WhatsApp%20Num-03094161457-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<img src="blackmafia32.jpg">
<p align="center">
<p align="center">
<a href="https://github.com/lovehacker404"><img title="Author" src="https://img.shields.io/badge/Author-lovehacker404-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/lovehacker404/followers"><img title="Followers" src="https://img.shields.io/github/followers/lovehacker404?color=blue&style=flat-square"></a>
<a href="https://github.com/lovehacker404/World/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/lovehacker404/World?color=red&style=flat-square"></a>
<a href="https://github.com/lovehacker404/World/network/members"><img title="Forks" src="https://img.shields.io/github/forks/lovehacker404/World?color=red&style=flat-square"></a>
<a href="https://github.com/lovehacker404/World/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/lovehacker404/World?label=Watchers&color=blue&style=flat-square"></a>
</p>

# Installation :


`git clone https://github.com/lovehacker404/BlackMafia-Server/`

`cd BlackMafia-Server/`

`chmod 777 *`

`./Android-Setup.sh`


